
package QLSV;
import java.sql.*;
import java.util.*;

public class QLGiaoVien {
    public Scanner Scan = new Scanner(System.in);
    public int MenuQLGV(){
        System.out.println("------------Quan Ly Giao Vien----------");
                    System.out.println("1.Them Giao Vien moi");
                    System.out.println("2.Sua thong tin Giao Vien");
                    System.out.println("3.In danh sach Giao Vien");
                    System.out.println("4.Tim kiem Giao Vien");
                    System.out.println("5.Exit");
                    System.out.print("Ban Chon : ");
                   int n = Scan.nextInt();
               return n;
    }
public String AddGV()
    {
                            System.out.println("----------------Them Ho So Giao Vien Moi------------------");
                            System.out.print("Ma Giao Vien : ");
                            String MaGV = Scan.nextLine();
                            MaGV = Scan.nextLine();
                            System.out.print("Ho Giao Vien: ");
                            String HoGV = Scan.nextLine();
                            System.out.print("Ten Giao Vien :");
                            String TenGV = Scan.nextLine();
                            System.out.print("Don Vi :");
                            String DonVi = Scan.nextLine();
              String url = "insert into GiaoVien values ('"+MaGV+"','"+HoGV+"','"+TenGV+"','"+DonVi+"')";
              return url;
        
    }
    
 public void SetGV(Statement stmt) throws SQLException
     {
                  
          System.out.print("ma Giao vien muon cap nhat : "); 
          String MaGV = Scan.nextLine();         
           System.out.println("-------------------Sua thong tin Giao Vien---------------------");
                            System.out.print("Ma Giao Vien : ");
                            String MaGV1 = Scan.nextLine();
                            System.out.print("Ho Giao Vien : ");
                            String HoGV=Scan.nextLine();
      
                            System.out.print("Ten Giao Vien :");
                            String TenGV = Scan.nextLine();
                            System.out.print("Don Vi :");
                            String DonVi = Scan.nextLine();
                            String url ="Update GiaoVien Set MaGV='"+MaGV1+"',HoGV='"+HoGV+"',TenGV='"+TenGV+"',DonVi='"+DonVi+"' where MaGV='"+MaGV+"'";
                        try {
                            boolean rs = stmt.execute(url);
                            System.out.println("Cap nhat giao vien thanh cong");
         } catch (SQLException e) {
                            System.out.println("ma giao vien da ton tai");
         }
        
                
     } 
public void ShowGV(Statement stmt ) throws SQLException
     {
         ResultSet rs = stmt.executeQuery("select*from GiaoVien");
         if (!rs.next()) System.out.println("danh sach giao vien trong");
         else
         {
           System.out.println("----------------------Danh sach Giao Vien-----------------------");
           System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4));

            while (rs.next())
                            {
                                System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4));
                            }
         } 
     }
 public void SearchGV(Statement stmt) throws SQLException
     {  
          System.out.print("Nhap MaGV hoac Ho va Ten Giao Vien : ");
          String MaGV = Scan.nextLine();
                 MaGV = Scan.nextLine();
          ResultSet rs=null;
         String CheckMaGV = "GV\\w{3,}" ;
        if (MaGV.matches(CheckMaGV))
        {
            String SearchURL = "select * from GiaoVien where MaGV='"+MaGV+"'";
            rs = stmt.executeQuery(SearchURL);
           if (!rs.next()) System.out.println("Khong tim thay ma giao vien");
           else
           {
           
               System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)); 
               while (rs.next())
               {
                        System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)); 
               }
           }
           
        } else 
        {
            String checkGV = "\\w{1,}\\s\\w{1,}.{0,}";
            if (MaGV.matches(checkGV))
            {
           int i= MaGV.length(); String HoGV=null,TenGV=null;  String SearchURL=null;
            while (i>0)
            {
                if (MaGV.charAt(i-1)==' ')
                {
                    HoGV=MaGV.substring(0, i-1);
                    TenGV=MaGV.substring(i, MaGV.length());
                   SearchURL = "select * from GiaoVien where HoGV='"+HoGV+"'and TenGV='"+TenGV+"'";
                    break;
                }
                else i--;
            }
                        
            rs =stmt.executeQuery(SearchURL);
               if (!rs.next()) System.out.println("Khong tim thay giao vien");
           else
           {
           
               System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)); 
               while (rs.next())
               {
                        System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)); 
               }
           }
        }
            else System.out.println("Ban nhap sai dinh dang");
        }
     }  
    
}
