package QLSV;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.*;
public class Main {
    public Scanner Scan = new Scanner(System.in);
    public int MenuQLSV()
    {
        
        System.out.println("--------------------MENU------------------------");
        System.out.println("1.Quan Ly Mon Hoc");
        System.out.println("2.Quan Ly Giao Vien");
        System.out.println("3.Quan Ly Sinh Vien");
        System.out.println("4.Quan Ly Lop");
        System.out.println("5.Quan Ly Diem");
        System.out.println("6.Quan Tri He Thong");
        System.out.println("7.Exit");
        
        System.out.print("Ban Chon : ");
     
         int n = Scan.nextInt();
       
         return n;
        
         }
    public static void main(String args[]) throws ClassNotFoundException, SQLException, IOException, InterruptedException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
      Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/QLSV","root","phuongthanh");
      Statement stmt = connection.createStatement();
      int select,n;
     
      Main QLSV = new Main();
      Scanner Scan = new Scanner(System.in);
      
        do {
             QLMonHoc QLMH = new QLMonHoc();
              select = QLSV.MenuQLSV();
            
            if ( select>8 || select<1) System.out.println("Ban nhap sai, moi nhap lai");
            else
                switch(select)
                 {
                    case 1:
                        do{
                              n =QLMH.MenuQLMH();
                            if ( n>4 || n<1) System.out.println("Ban nhap sai, moi nhap lai");
                            else
                     switch(n)
                    {
                        case 1 : 
                         QLMH.AddMH(stmt);
                        break;
                        case 2:
                             System.out.print("Ma mon hoc : "); 
                             String MaMH = Scan.nextLine();
                             ResultSet rs = QLMH.SearchMH(stmt,MaMH);
                            if (rs.next()==false)
                                System.out.println("Khong ton tai mon hoc");
                           else 
                            {
                                System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
                                QLMH.SetMH(stmt, MaMH);
                            }
                        break;
                            
                        case 3:
                          
                             rs = stmt.executeQuery("select*from MonHoc");
                           QLMH.ShowMH(rs);
                        break;
                     }
                 } while (n!=4);
                       
                   
               break;
               
               case 2:
                     do{
                           QLGiaoVien QLGV = new QLGiaoVien();
                           n = QLGV.MenuQLGV();
                           if (n<1 || n>5) System.out.println("Ban nhap sai, moi nhap lai");
                           else
                          switch(n)
                    {
                        case 1 : 
                           
                            
                            String urlAddGV = QLGV.AddGV();
                            try {
                                boolean rs = stmt.execute(urlAddGV);
                                System.out.println("Them Giao Vien thanh cong");
                            } catch (SQLException e) {
                                System.out.println("Ma Giao Vien da ton tai");
                            }
                            
                        break;
                        case 2:
                           
                              QLGV.SearchGV(stmt);
                              QLGV.SetGV(stmt);
                        
                        break;
                        case 3: 
                            
                          QLGV.ShowGV(stmt); 
                            
                        break;
                        case 4:
                           
                            QLGV.SearchGV(stmt);
       
                        break;

                     }
                } while (n!=5);
               break;
             case 3:
                 do{
                           QLSinhVien QLSV1 = new QLSinhVien();
                           n = QLSV1.MenuQLSV();
                           if (n<1 || n>4) System.out.println("Ban nhap sai, moi nhap lai");
                           else
                          switch(n)
                    {
                        case 1 : 
                           
                            
                            String urlAddSV = QLSV1.AddSV();
                            try {
                                boolean rs = stmt.execute(urlAddSV);
                                System.out.println("Them Sinh Vien thanh cong");
                            } catch (SQLException e) {
                               
                                System.out.println("Sinh Vien da ton tai hoac nhap sai dinh dang");
                            }
                            
                        break;
                        case 2:
                            
                            QLSV1.SearchSV(stmt);
                            QLSV1.SetSV(stmt);
                            
              
                        break;
                       
                        case 3:
                              
                              QLSV1.SearchSV(stmt);
                               
                        break;

                     }
                } while (n!=4);
             break;
             
             case 4:
                  do{
                           QLLop QLL = new QLLop();
                           n = QLL.MenuQLLop();
                           if (n<1 || n>8) System.out.println("Ban nhap sai, moi nhap lai");
                           else
                          switch(n)
                    {
                        case 1 : 
                           
                               QLL.AddLop(stmt);
                            
                        break;
                        case 2:
                           QLL.SetLop(stmt);
                          
                        break;

                       
                        case 3:
                           QLL.AddSVLop(stmt);
                         break;

                        case 4:
                             
                            QLL.DeteleSVLop(stmt);
                          
                        break;
                        case 5:
                            boolean rs1 = false;
                              QLL.DeteleLop(rs1,stmt);
                            System.out.println("Xoa lop Thanh Cong");
                        break;

                        case 6:
                          boolean ShowLop = QLL.ShowLop(stmt,null);
                         break;
                        case 7:
                            QLL.ShowSVL(stmt);
                        break;
                       }
                } while (n!=8);
              
             break;
             
             case 5:
                  do{
                      QLDiem QLD = new QLDiem();
                              n =QLD.MenuQLDiem();
                            if ( n>5 || n<1) System.out.println("Ban nhap sai, moi nhap lai");
                            else
                     switch(n)
                    {
                        case 1 : 
                            
                          QLD.AddDiem(stmt);
                        break;
                        case 2:
                          QLD.AddDiem(stmt); //AddDiem == SetDiem
  
                        break;
                        case 3:
                            QLD.ShowDiemLop(stmt);
                        break;
                        case 4:
                            QLD.ShowDiemSV(stmt);
                        break;
                     }
                 } while (n!=5);
                       
                   
             break;    
             case 6:
             
                   do
                   {
                       System.out.println("1.Cai dat lai Database ");
                       System.out.println("2.Sao luu Database ");
                       System.out.println("3.Exit");
                       n = Scan.nextInt();
                       if (n<1 || n>5) System.out.println("Ban nhap sai, moi nhap lai");
                       else
                       {
                                   File f1 = new File("C:\\backup\\backupDatabase.sql");
                                   File f2 = new File("C:\\backup\\backupMH.sql");
                                   File f3 = new File("C:\\backup\\backupGV.sql");
                                   File f4 = new File("C:\\backup\\backupSV.sql");
                                   File f5 = new File("C:\\backup\\backupL.sql");
                                   File f6 = new File("C:\\backup\\backupSVL.sql");
                           switch(n)
                           {
                             case 1: 
                                   ImportSQL importSQL = new ImportSQL();
                                   importSQL.backupDatabase(stmt, f1,"QLSV");
                                   importSQL.backup(stmt, f2,"MonHoc");
                                   importSQL.backup(stmt, f3,"GiaoVien");
                                   importSQL.backup(stmt, f4,"SinhVien");
                                   importSQL.backup(stmt, f5,"Lop");
                                   importSQL.backup(stmt, f6,"SinhVienLop");
                               break;
                           /*    case 1:
                               
                                   System.out.println("Sao lưu dữ liệu");
                                 
			         String executeCmd = "C:\\Program Files\\MySQL\\MySQL Server 8.0\\bin\\mysqldump -u root -pphuongthanh qlsv -r C:\\backup\\test.sql";
			    
			   Process runtimeProcess =Runtime.getRuntime().exec(executeCmd);
			    int processComplete = runtimeProcess.waitFor();
			    if(processComplete == 0){
				System.out.println("Backup taken successfully");
			    } else {
				System.out.println("Could not take mysql backup");
			    }

			    break;*/
			    
                               case 2:
                                   ExportSQL exportSQL = new ExportSQL();
                                   exportSQL.WriteDatabase(stmt,f1);
                                   exportSQL.WriteMH(stmt, f2);
                                   exportSQL.WriteGV(stmt, f3);
                                   exportSQL.WriteSV(stmt, f4);
                                   exportSQL.WriteL(stmt, f5);
                                   exportSQL.WriteSVL(stmt,f6);
                                   
                               break;
                                                                   
                           }
                       }
                      
                   } while (n!=3);
                     
             break;
                 
                    
                
                
            

        }      
                
        }   while (select!=7);
        
    }
}
