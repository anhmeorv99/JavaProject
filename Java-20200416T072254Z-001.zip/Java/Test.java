/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QLSV;

import java.sql.*;
public class Test {
    public ResultSet checkData(Statement stmt,String table,String st) throws SQLException
    {
        ResultSet rs = stmt.executeQuery("select*from "+table+" where text='"+st+"'");
        return rs;
        
    }
  
    public String sinhStr(String st,Statement stmt,String table) throws SQLException
{
   
   boolean rs;
   
       while(st.contains("I")|| st.contains("E") || st.contains("O")|| st.contains("Y") )
        {
          
            
                 if (st.contains("I"))
            {
                String st1 = st.replaceFirst("I","!");
                ResultSet rscheck=checkData(stmt, table, st) ;
                if (rscheck.next()==false)
                rs = stmt.execute("insert into "+table+" values ('"+st1+"')");
                return sinhStr(st1,stmt,table);
            } 
                 if (st.contains("E"))
            {
                String st1 = st.replaceFirst("E","€");
                 ResultSet rscheck=checkData(stmt, table, st) ;
                if (rscheck.next()==false)
                rs = stmt.execute("insert into "+table+" values ('"+st1+"')");
                return sinhStr(st1,stmt,table);
            } 
                      if (st.contains("O"))
            {
                String st1 = st.replaceFirst("O","0");
                 ResultSet rscheck=checkData(stmt, table, st) ;
                if (rscheck.next()==false)
                rs = stmt.execute("insert into "+table+" values ('"+st1+"')");
                return sinhStr(st1,stmt,table);
            } 
                 if (st.contains("Y"))
            {
                String st1 = st.replaceFirst("Y","¥");
                 ResultSet rscheck=checkData(stmt, table, st) ;
                if (rscheck.next()==false)
               rs = stmt.execute("insert into "+table+" values ('"+st1+"')");
                return sinhStr(st1,stmt,table);
            }
            
            
         }
      return null;
}
      public void InputData(Statement stmt,String table) throws SQLException
    {
        ResultSet rs = stmt.executeQuery("Select*from "+table);
        while (rs.next())
        {
            String sinhStr = sinhStr(rs.getString(1),stmt,table);
        }
       
    }
        
        

    public static void main(String args[]) throws ClassNotFoundException, SQLException 
    {
        
           Test sms = new Test();
           Class.forName("com.mysql.cj.jdbc.Driver");
      Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/SMS","root","phuongthanh");
      Statement stmt = connection.createStatement();
        sms.InputData(stmt,"LoiChao");
        
    }
    
}
