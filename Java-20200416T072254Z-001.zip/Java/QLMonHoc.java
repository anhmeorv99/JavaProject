package QLSV;

import java.sql.*;
import java.util.*;
public class QLMonHoc {
    public Scanner scan = new Scanner(System.in);
    
    public int MenuQLMH(){
            
      
               
                    System.out.println("------------Quan Ly Mon Hoc----------");
                    System.out.println("1.Them mon hoc moi");
                    System.out.println("2.Sua thong tin mon hoc");
                    System.out.println("3.In danh sach mon hoc");
                    System.out.println("4.Exit");
                    System.out.print("Ban Chon : ");
                int n = scan.nextInt();
                return n;
         }
    public boolean checkMH(String MaMH)
{
        String CheckMaMH = "MH\\w{3,}" ;
        return (MaMH.matches(CheckMaMH));
}
    
    public void AddMH(Statement stmt) throws SQLException
    {
                            System.out.println("----------------Them Mon Hoc Moi------------------");
                            System.out.print("Ma mon hoc : ");
                            String MaMH = scan.nextLine();
                            MaMH = scan.nextLine();
                            System.out.print("Ten Mon Hoc: ");
                            String TenMH = scan.nextLine();
                            System.out.print("So Tin Chi :");
                            int SoTC = scan.nextInt();
                            try {
                           //     if (checkMH(MaMH)==true)
                           //     {
                                 String url = "insert into MonHoc values ('"+MaMH+"','"+TenMH+"','"+SoTC+"')";
                                    boolean rs = stmt.execute(url);
                                   System.out.println("Them mon hoc thanh cong");
                             //   } else  System.out.println("Sai Dinh dang Ma Mon Hoc");
                             } catch (SQLException e) {
                                    System.out.println("Ma mon hoc da ton tai");
                              }
                          
                        
                             
        
    }
   
     public void SetMH(Statement stmt,String MaMH) throws SQLException
     {
                           
                  System.out.println("-------------------Sua thong tin mon hoc---------------------");
                  
                                    System.out.print("Ma Mon Hoc :");
                                   String  MaMH1 = scan.nextLine();
                                     MaMH1= scan.nextLine();
                                    System.out.print("Ten Mon Hoc : ");
                                    String TenMH=scan.nextLine();
                                   
                                    System.out.print("So Tin Chi :");
                                    int SoTC=scan.nextInt();
                                    try {
                               //          if (checkMH(MaMH1)==true)
                               //{
                                    String url ="Update MonHoc Set MaMH='"+MaMH1+"',"+" TenMH='"+TenMH+"',SoTC="+SoTC+" where MaMH='"+MaMH+"'";
                                    boolean rs = stmt.execute(url);
                                   System.out.println("Sua mon hoc thanh cong");
                                //} else  System.out.println("Sai Dinh dang Ma Mon Hoc");
             
         } catch (SQLException e) {
              System.out.println("Ma mon hoc da ton tai");
         }
                                 
                               
              
     }
                        
                            
                            
     public void ShowMH(ResultSet rs ) throws SQLException
     {
           System.out.println("----------------------Danh sach mon hoc-----------------------");
             // System.out.println("MaMH\t\tTenMH\t\tSoTC");
            while (rs.next())
                            {
                                System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
                            }
            
           
     }
     public ResultSet SearchMH(Statement stmt,String MaMH) throws SQLException
     {  
            String SearchURL = "select * from MonHoc where MaMH='"+MaMH+"'";
            ResultSet rs = stmt.executeQuery(SearchURL);
         return rs;
     }
                                 
    }      
           
          
            
  
