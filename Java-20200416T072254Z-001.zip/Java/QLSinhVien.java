
package QLSV;
import java.sql.*;
import java.util.*;

public class QLSinhVien {
    public Scanner Scan = new Scanner(System.in);
    public int MenuQLSV(){
        System.out.println("------------Quan Ly Sinh Vien----------");
                    System.out.println("1.Them Sinh Vien moi");
                    System.out.println("2.Sua thong tin Sinh Vien");
                    System.out.println("3.Tim kiem Sinh Vien");
                    System.out.println("4.Exit");
                    System.out.print("Ban Chon : ");
                   int n = Scan.nextInt();
               return n;
    }
public String AddSV()
    {
                            System.out.println("----------------Them Ho So Sinh Vien Moi------------------");
                            System.out.print("Ma Sinh Vien : ");
                            String MaSV = Scan.nextLine();
                            MaSV = Scan.nextLine();
                            System.out.print("Ho Sinh Vien: ");
                            String HoSV = Scan.nextLine();
                            System.out.print("Ten Sinh Vien :");
                            String TenSV = Scan.nextLine();
                            System.out.print("Ngay Sinh :");
                            String NgaySinh = Scan.nextLine();
                            System.out.print("Noi Sinh :");
                            String NoiSinh = Scan.nextLine();
                            
                            
              String url = "insert into SinhVien values ('"+MaSV+"','"+HoSV+"','"+TenSV+"','"+NgaySinh+"','"+NoiSinh+"')";
              return url;
        
    }
    
 public void SetSV(Statement stmt) throws SQLException
     {
          System.out.print("ma sinh vien muon cap nhat : "); 
          String MaSV = Scan.nextLine();
           System.out.println("-------------------Sua thong tin Sinh Vien---------------------");
                            System.out.print("Ma Sinh Vien : ");
                            String MaSV1 = Scan.nextLine();
                                  // MaSV1 =Scan.nextLine();
                            System.out.print("Ho Sinh Vien : ");
                            String HoSV=Scan.nextLine();
                               
                            System.out.print("Ten Sinh Vien :");
                            String TenSV = Scan.nextLine();
                            System.out.print("Ngay Sinh :");
                            String NgaySinh = Scan.nextLine();
                            System.out.print("Noi Sinh :");
                            String NoiSinh = Scan.nextLine();
              try {
                    String url ="Update SinhVien Set MaSV='"+MaSV1+"',HoSV='"+HoSV+"',TenSV='"+TenSV+"',NgaySinh='"+NgaySinh+"',NoiSinh='"+NoiSinh+"' where MaSV='"+MaSV+"'";
               boolean rs = stmt.execute(url);
                  System.out.println("Cap nhap sinh vien thanh cong");
         } catch (SQLException e) {
                  System.out.println("Ma sinh vien da ton tai");
         }
              
                     
             
     } 
public void ShowSV(ResultSet rs ) throws SQLException
     {
           System.out.println("----------------------Danh sach Sinh Vien-----------------------");
            while (rs.next())
                            {
                                System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+" "+rs.getString(5));
                            }
           
     }
public void SearchSV(Statement stmt) throws SQLException
     {  
          System.out.print("Nhap MaSV hoac Ho va Ten Sinh Vien : ");
          String MaGV = Scan.nextLine();
                 MaGV = Scan.nextLine();
          ResultSet rs=null;
         String CheckMaGV = "SV\\w{3,}" ;
        if (MaGV.matches(CheckMaGV))
        {
            String SearchURL = "select * from SinhVien where MaSV='"+MaGV+"'";
            rs = stmt.executeQuery(SearchURL);
           if (!rs.next()) System.out.println("Khong tim thay ma sinh vien");
           else
           {
           
               System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+" "+rs.getString(5)); 
               while (rs.next())
               {
                        System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+" "+rs.getString(5)); 
               }
           }
           
        } else 
        {
            String checkGV = "\\w{1,}\\s\\w{1,}.{0,}";
            if (MaGV.matches(checkGV))
            {
           int i= MaGV.length(); String HoGV=null,TenGV=null;  String SearchURL=null;
            while (i>0)
            {
                if (MaGV.charAt(i-1)==' ')
                {
                    HoGV=MaGV.substring(0, i-1);
                    TenGV=MaGV.substring(i, MaGV.length());
                   SearchURL = "select * from SinhVien where HoSV='"+HoGV+"'and TenSV='"+TenGV+"'";
                    break;
                }
                else i--;
            }
                        
            rs =stmt.executeQuery(SearchURL);
               if (!rs.next()) System.out.println("Khong tim thay sinh vien");
           else
           {
           
               System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)); 
               while (rs.next())
               {
                        System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)); 
               }
           }
        }
            else System.out.println("Ban nhap sai dinh dang");
        }
     } 
 public boolean checkSV(Statement stmt,String MaSV)
{
        String CheckMaSV = "SV\\w{3,}" ;
        if (MaSV.matches(CheckMaSV)) return true;
        else
        {
            System.out.println("Sai dinh dang ma sinh vien");
            return false;
        }
       
}
    
}

