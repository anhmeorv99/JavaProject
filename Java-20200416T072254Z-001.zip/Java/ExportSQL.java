/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QLSV;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ExportSQL {
   public void WriteDatabase(Statement stmt,File f) throws SQLException, IOException 
    {
        
            ResultSet rs=null;
         //   File f = new File("C:\\backup\\backupDatabase.txt");
            try (FileWriter fw = new FileWriter(f)) {
               
                  fw.write(
"CREATE TABLE MonHoc(MaMH VARCHAR(10) primary key,"
                  + "TenMH VARCHAR(30) not null,SoTC int not null)\n" +
"CREATE TABLE GiaoVien(MaGV VARCHAR(10) primary key,"
                    + "HoGV VARCHAR(20) not null,"
                    + "TenGV VARCHAR(10) not null,"
                    + "DonVi VARCHAR(50) not null)\n" +
"CREATE TABLE SinhVien(MaSV VARCHAR(10) primary key,"
                    + "HoSV VARCHAR(20) not null,"
                    + "TenSV VARCHAR(10) not null,"
                    + "ngaysinh date,noisinh varchar(50) not null)\n" +
"CREATE TABLE Lop(MaLop VARCHAR(10) primary key,"
                    + "MaMH VARCHAR(10) not null,"
                    + "NamHoc VARCHAR(10) not null,"
                    + "HocKy int not null,"
                    + "MaGV varchar(10) not null,"
                    + "FOREIGN key (MaMH) references MonHoc(MaMH),"
                    + "FOREIGN key (MaGV) references GiaoVien(MaGV))\n" +
"CREATE TABLE SinhVienLop(MaSV varchar(10) not null,"
                       + "MaLop varchar(10) not null,"
                       + "Diem double,primary key (MaSV,MaLop),"
                       + "FOREIGN key (MaSV) references SinhVien(MaSV),"
                       + "FOREIGN key (MaLop) references Lop(MaLop))");
                  
                   System.out.println("ghi file Database thanh cong");
            } catch(Exception e) {
                System.out.println("loi ghi file MonHoc");
            }
    }
     public void WriteMH(Statement stmt,File f) throws SQLException, IOException 
    {
        
            ResultSet rs=null;
          //  File f = new File("C:\\backup\\backupMH.txt");
            try (FileWriter fw = new FileWriter(f)) {
                rs = stmt.executeQuery("SELECT*from monhoc");
                while (rs.next())
                {
                    fw.write("insert into MonHoc value ('"+rs.getString(1)+"','"+rs.getString(2)+"','"
                    +rs.getString(3)+"')\n");
                }
                   System.out.println("ghi file MonHoc thanh cong");
            } catch(Exception e) {
                System.out.println("loi ghi file MonHoc");
            }
    }
     public void WriteSVL(Statement stmt,File f) throws SQLException, IOException 
    {
        
            ResultSet rs;
      //      File f = new File("C:\\backup\\backupSVL.txt");
            try (FileWriter fw = new FileWriter(f)) {
                rs = stmt.executeQuery("SELECT*from SinhVienLop");
                while (rs.next())
                {
                    fw.write("insert into SinhVienLop value ('"+rs.getString(1)+"','"+rs.getString(2)+"','"
                    +rs.getString(3)+"')\n");
                }
                   System.out.println("ghi file SinhVienLop thanh cong");
            } catch(Exception e) {
                System.out.println("loi ghi file");
            }
    }
       public void WriteGV(Statement stmt,File f) throws SQLException, IOException 
    {
        
            ResultSet rs;
           // File f = new File("C:\\backup\\backupGV.txt");
            try (FileWriter fw = new FileWriter(f)) {
                rs = stmt.executeQuery("SELECT*from GiaoVien");
                while (rs.next())
                {
                    fw.write("insert into GiaoVien value ('"+rs.getString(1)+"','"+rs.getString(2)+"','"
                    +rs.getString(3)+"','"+rs.getString(4)+"')\n");
                }
                   System.out.println("ghi file GiaoVien cong");
            } catch(Exception e) {
                System.out.println("loi ghi file GiaoVien");
            }
    }
       
         public void WriteSV(Statement stmt,File f) throws SQLException, IOException 
    {
        
            ResultSet rs;
        //    File f = new File("C:\\backup\\backupSV.txt");
            try (FileWriter fw = new FileWriter(f)) {
                rs = stmt.executeQuery("SELECT*from SinhVien");
                while (rs.next())
                {
                   
                    fw.write("insert into SinhVien value ('"+rs.getString(1)+"','"+rs.getString(2)+"','"
                    +rs.getString(3)+"','"+rs.getString(4)+"','"+rs.getString(5)+"')\n");
                }
                   System.out.println("ghi file SinhVien thanh cong");
            } catch(Exception e) {
                System.out.println("loi ghi file");
            }
    }
         
           public void WriteL(Statement stmt,File f) throws SQLException, IOException 
    {
        
            ResultSet rs;
         //   File f = new File("C:\\backup\\backupL.txt");
            try (FileWriter fw = new FileWriter(f)) {
                rs = stmt.executeQuery("SELECT*from Lop");
                while (rs.next())
                {
                    fw.write("insert into Lop value ('"+rs.getString(1)+"','"+rs.getString(2)+"','"
                    +rs.getString(3)+"','"+rs.getString(4)+"','"+rs.getString(5)+"')\n");
                }
                   System.out.println("ghi file Lop thanh cong");
            } catch(Exception e) {
                System.out.println("loi ghi file");
            }
    }
    
}
