
package QLSV;
import java.util.*;
import java.sql.*;
public class QLLop {
    Scanner Scan = new Scanner(System.in);
    public int MenuQLLop()
    {
        System.out.println("----------------------Quan ly Lop----------------------");
        System.out.println("1.Tao Lop Moi");
        System.out.println("2.Sua Doi thong tin lop");
        System.out.println("3.Them Sinh Vien vao lop");
        System.out.println("4.Loai bo Sinh Vien khoi lop");
        System.out.println("5.Huy lop"); 
        System.out.println("6.In danh sach lop");
        System.out.println("7.In danh sach sinh vien trong lop");
        System.out.println("8.Exit");
        int n = Scan.nextInt();
        return n;
    }
    public boolean checkMaMH(Statement stmt,String MaMH) throws SQLException
    {
        ResultSet rs = stmt.executeQuery("select *from MonHoc where MaMH='"+MaMH+"'");
        return rs.next();
    }
     public boolean checkMaGV(Statement stmt,String MaGV) throws SQLException
    {
        ResultSet rs = stmt.executeQuery("select *from GiaoVien where MaGV='"+MaGV+"'");
        return rs.next();
    }
    public void AddLop(Statement stmt) throws SQLException
    {
                            System.out.println("----------------Tao Lop Moi------------------");
                            System.out.print("Ma Lop : ");
                            String MaLop = Scan.nextLine();
                            MaLop = Scan.nextLine();
                            System.out.print("Ma Mon Hoc: ");
                            String MaMH = Scan.nextLine();
                            System.out.print("Nam Hoc :");
                            String NamHoc = Scan.nextLine();
                            System.out.print("Hoc ky :");
                            String HocKy = Scan.nextLine();
                            System.out.print("Ma GV :");
                            String MaGV = Scan.nextLine();
                            try {
                          String url = "insert into Lop values ('"+MaLop+"','"+MaMH+"','"+NamHoc+"','"+HocKy+"','"+MaGV+"')";
                          boolean rs = stmt.execute(url);
                                System.out.println("Tao lop thanh cong");
        } catch (SQLException e) {
                             if (checkMaGV(stmt, MaGV)==false) System.out.println("Khong ton tai ma giao vien");
   
                                if (checkMaMH(stmt, MaMH)==false) System.out.println("Khong ton tai ma mon hoc");
                                if (ShowLop(stmt, MaLop)) System.out.println("Ma Lop da ton tai");
                            
        }
           
        
    }
    public void SetLop(Statement stmt) throws SQLException
     {
           System.out.print("Ma Lop : ");
           String MaLop = Scan.nextLine();
           MaLop=Scan.nextLine();
           System.out.println("-------------------Sua thong tin Lop---------------------");
                           
                            System.out.print("Nam Hoc : ");
                            String NamHoc=Scan.nextLine();
                            System.out.print("Hoc Ky :");
                            String HocKy = Scan.nextLine();
                            System.out.print("Ma Giao Vien :");
                            String MaGV = Scan.nextLine();
                            try {
                                 String url ="Update Lop Set NamHoc='"+NamHoc+"',HocKy='"+HocKy+"',MaGV='"+MaGV+"' where MaLop='"+MaLop+"'";
                                 boolean rs = stmt.execute(url);
                                 System.out.println("Cap nhat lop thanh cong");
                            } catch (SQLException e) {
                             if (checkMaGV(stmt, MaGV)==false) System.out.println("Khong ton tai ma giao vien");
                            }
                           
                                
               
     } 
     public void AddSVLop(Statement stmt) throws SQLException
    {
                            System.out.println("----------------Them Sinh Vien vao lop------------------");
                            System.out.print("Ma Sinh Vien : ");
                            String MaSV = Scan.nextLine();
                            MaSV = Scan.nextLine();
                            System.out.print("Ma Lop: ");
                            String MaLop = Scan.nextLine();
                try {
                     String url = "insert into SinhVienLop(MaSV,MaLop) values ('"+MaSV+"','"+MaLop+"')";
 
                    boolean rs = stmt.execute(url);
                      System.out.println("Them sinh vien thanh cong");
        } catch (SQLException e) {
            if (ShowLop(stmt,MaLop)==false) System.out.println("khong ton tai ma lop");
            else System.out.println("ma sinh vien da ton tai hoac khong ton tai ma sinh vien");
        }
            
             
            
        
    }
     public void DeteleSVLop(Statement stmt) throws SQLException
    {
                            System.out.println("----------------Xoa Sinh vien lop------------------");
                            System.out.print("Ma Sinh Vien : ");
                            String MaSV = Scan.nextLine();
                            MaSV = Scan.nextLine();
                            System.out.print("Ma Lop: ");
                            String MaLop = Scan.nextLine();
              ResultSet rs = stmt.executeQuery("select*from SinhVienLop where MaSV='"+MaSV+"'and MaLop='"+MaLop+"'");
           if (rs.next())
           {
              String url = "delete from SinhVienLop where MaSV='"+MaSV+"'and MaLop='"+MaLop+"'";
              boolean rs1 = stmt.execute(url);
               System.out.println("Xoa sinh vien thanh cong");
           } else
           {
               if (ShowLop(stmt, MaLop))
               System.out.println("Khong ton tai sinh vien trong lop");
               else System.out.println("khong ton tai lop");
           }
        
    }
     public void DeteleLop(boolean rs, Statement stmt) throws SQLException
    {
                            System.out.println("----------------Xoa lop------------------");
                            
                            System.out.print("Ma Lop: ");
                            String MaLop = Scan.nextLine();
                                   MaLop= Scan.nextLine();
                    
                     rs= stmt.execute("delete from SinhVienLop where Malop='"+MaLop+"'");
                    rs = stmt.execute("delete from Lop where MaLop='"+MaLop+"'");
              
        
    }
     public void ShowSVL(Statement stmt) throws SQLException
     {
         
        System.out.print("Nhap Ma Lop :");
        String MaLop = Scan.nextLine();
               MaLop = Scan.nextLine();
              
            ResultSet  rs = stmt.executeQuery(" select SinhVienLop.MaSV,HoSV,TenSV from "
             + "(SinhVienLop inner join SinhVien on SinhvienLop.MaSV=SinhVien.MaSV) where Malop='"+MaLop+"'");
         if (!rs.next()) System.out.println("khong tim thay ma lop");
         else
         {
             System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
         
           while (rs.next())
           {
               System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
           }
         }
     }
      public boolean ShowLop(Statement stmt,String MaLop ) throws SQLException
     {
        
           ResultSet rs=null;
          
         if (MaLop==null)  
       
                 rs = stmt.executeQuery("select MaLop,TenMH,NamHoc,HocKy,"
                                    + "HoGV,TenGV from ((Lop join MonHoc on Lop.MaMH=MonHoc.MaMH) join "
                                    + "GiaoVien on Lop.maGV=GiaoVien.MaGV)");
         else
                
                 rs = stmt.executeQuery("select MaLop,TenMH,NamHoc,HocKy,"
                                    + "HoGV,TenGV from ((Lop join MonHoc on Lop.MaMH=MonHoc.MaMH) join "
                                    + "GiaoVien on Lop.maGV=GiaoVien.MaGV) where MaLop='"+MaLop+"'");
         if (!rs.next()) 
         {
            
             return false;
         }
         else
         {
              System.out.println("----------------------Danh sach Lop hoc-----------------------");
               System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "
                                        +rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6));
               while (rs.next())
                            {
                                System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "
                                        +rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6));
                            }
         }
            
         
            return true;
           
     }
     
    
     
    
}
