
package QLSV;
import java.sql.*;
import java.io.*;


public class ImportSQL{
    public void backupDatabase (Statement stmt,File f,String Database) 
    {
         Boolean rs=false;
        //    File f = new File("C:\\backup\\backupMH.txt");
            try (FileReader fr = new FileReader(f))
            {
                 BufferedReader br = new BufferedReader(fr);
                 String line;
                 while ((line = br.readLine()) != null){
                           rs = stmt.execute(line);
                       }
                 System.out.println("Backup database "+Database+" thanh cong");
            }
            catch (Exception e)
            {
                System.out.println("Backup database "+Database+" That Bai");
            }
    }
    public void backup(Statement stmt,File f,String Table) throws FileNotFoundException, IOException, SQLException
    {
           Boolean rs=false;
        //    File f = new File("C:\\backup\\backupMH.txt");
            try (FileReader fr = new FileReader(f))
            {
                 BufferedReader br = new BufferedReader(fr);
                 String line;
                 while ((line = br.readLine()) != null){
                           rs = stmt.execute(line);
                       }
                 System.out.println("Backup table "+Table+" thanh cong");
            }
            catch (Exception e)
            {
                System.out.println("Backup table "+Table+" That Bai");
            }
    }
}