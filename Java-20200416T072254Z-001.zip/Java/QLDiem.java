
package QLSV;

import java.sql.*;
import java.util.*;
public class QLDiem {
        Scanner Scan = new Scanner(System.in);
         public int MenuQLDiem()
    {
        System.out.println("----------------------Quan ly Diem----------------------");
        System.out.println("1.Nhap Diem");
        System.out.println("2.Sua Diem");
        System.out.println("3.In ra bang diem cho lop");
        System.out.println("4.In ra bang diem cho Sinh Vien");
        System.out.println("5.Exit");
        int n = Scan.nextInt();
        return n;
    }
         
    
    public void AddDiem(Statement stmt) throws SQLException
    {
                            System.out.println("----------------Nhap Diem------------------");
                            System.out.print("Ma Lop : ");
                            String MaLop = Scan.nextLine();
                            MaLop = Scan.nextLine();
                            System.out.print("Ma Sinh Vien: ");
                            String MaSV = Scan.nextLine();
                     ResultSet rs = stmt.executeQuery("select *from SinhVienLop where MaLop='"+MaLop+"' and MaSV='"+MaSV+"'");
                       if (rs.next())
                       {
                           System.out.print("Diem :");
                            Double Diem = Scan.nextDouble();
                               String url ="Update SinhVienLop Set Diem="+Diem+" where MaLop='"+MaLop+"'and MaSV='"+MaSV+"'";
                          boolean rs1 = stmt.execute(url);
                           System.out.println("Nhap diem thanh cong");
                       } else System.out.println("Khong tim thay sinh vien hoac lop");
               
    }
/*    public void SetDiem(Statement stmt,String MaLop, String MaSV)
     {
                           
           System.out.println("-------------------Sua Diem---------------------");
                              
                            System.out.print("Diem : ");
                            Double Diem=Scan.nextDouble();
                            String url ="Update SinhVienLop Set Diem="+Diem+" where MaLop='"+MaLop+"'and MaSV='"+MaSV+"'";
                                
                return url;
     } */
    public void ShowDiemLop(Statement stmt) throws SQLException
    {
       
        System.out.print("Nhap Ma Lop :");
        String MaLop = Scan.nextLine();
               MaLop = Scan.nextLine();
              
            ResultSet  rs = stmt.executeQuery(" select SinhVienLop.MaSV,HoSV,TenSV,Diem from "
             + "(SinhVienLop inner join SinhVien on SinhvienLop.MaSV=SinhVien.MaSV) where Malop='"+MaLop+"'");
         if (!rs.next()) System.out.println("khong tim thay ma lop");
         else
         {
             System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4));
         
           while (rs.next())
           {
               System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4));
           }
         }
         
    }
    
    
 
     public void ShowDiemSV(Statement stmt) throws SQLException
    {
        ResultSet rs;
         System.out.print("Nhap Ma Sinh Vien :");
         String MaSV = Scan.nextLine();
                MaSV = Scan.nextLine();
            rs = stmt.executeQuery("select SinhVienLop.MaSV,HoSV,TenSv,tenMH,diem from" +
    "(((SinhVienLop join Lop on SinhVienLop.MaLop=Lop.MaLop) "
                    + "join SinhVien on SinhVienLop.MaSV=SinhVien.MaSV) "
                    + "join MonHoc on MonHoc.MaMH=Lop.MaMH)" +
    "where SinhVienLop.MaSV='"+MaSV+"'");
    if (!rs.next()) System.out.println("khong tim thay sinh vien");
    else
        {
             System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "
               +rs.getString(5));
           while (rs.next())
           {
               System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "
               +rs.getString(5));
           }
        }
    }
}




